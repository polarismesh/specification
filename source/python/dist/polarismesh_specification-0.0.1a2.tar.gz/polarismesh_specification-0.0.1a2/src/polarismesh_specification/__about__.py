# SPDX-FileCopyrightText: 2023-present {authemail@qq.com} <authemail@qq.com>
#
# SPDX-License-Identifier: MIT
__version__ = '0.0.1-alpha.2'
